To understand what i am doing
to pass hopefully with a 70 or higher
to have fun while doing it

Message: These are my goals for this semester