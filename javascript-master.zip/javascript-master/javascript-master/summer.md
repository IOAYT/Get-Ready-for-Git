#What i Did This Summer
Went to the movies alot
Did my G2 test but failed
Well thats about it

Message: Creates the summer.md file